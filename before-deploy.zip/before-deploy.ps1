Write-Host $env:username
Write-Host "Launching .Net App CreateProcessAsUserApp"
start-process "C:\latest\zm-windows-comp\ZimbraMAPIInstaller\CreateProcessAsUserLib\CreateProcessAsUserApp\bin\Debug\CreateProcessAsUserApp.exe"