Write-Host $env:username
Write-Host "Launching .Net App CreateProcessAsUserApp"
Start-Process -FilePath "C:\CreateProcessAsUserApp\CreateProcessAsUserApp.exe"
