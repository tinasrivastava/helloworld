cd "C:\PSTExtractor_Sep23_ZCOMT-1787"
pwd
Write-Host "Calling PSTExtractor"
.\ExecutePSTExtractor.bat
