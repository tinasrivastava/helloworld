Write-Host $env:username
Write-Host "Launching CreateProcessAsUserApp"
start-process "C:\WinService\CreateProcessAsUser-master\CreateProcessAsUser-master\CreateProcessAsUserApp\bin\Debug\CreateProcessAsUserApp.exe"