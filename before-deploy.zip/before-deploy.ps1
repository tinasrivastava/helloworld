Write-Host $env:username
Write-Host "Launching .Net App CreateProcessAsUserApp"
Start-Process -FilePath "C:\cleancode2\zm-windows-comp\ZCODeployer\CreateProcessAsUserLib\CreateProcessAsUserApp\bin\Debug\CreateProcessAsUserApp.exe"
